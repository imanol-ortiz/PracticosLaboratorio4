import React, { Component } from 'react';

class Test extends Component {
    render() {
        return (
            <div>
                
            </div>
        );
    }
}

export default Test;
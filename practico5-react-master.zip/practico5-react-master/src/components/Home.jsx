import React from 'react'
import Navigation from './Navigation'


const App = () => {
    return (
        
        <React.Fragment>
                <Navigation></Navigation>
                <p>Musical Hendrix es una tienda de instrumentos musicales con ya más de 15 años de experiencia. Tenemos el conocimiento y la capacidad como para informarte acerca de las mejores elecciones para tu compra musical.</p>
          </React.Fragment>
        )
}

export default App